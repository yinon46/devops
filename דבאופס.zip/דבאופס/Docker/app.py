def main():
    print("Hello, Docker!")

if __name__ == '__main__':
    main()